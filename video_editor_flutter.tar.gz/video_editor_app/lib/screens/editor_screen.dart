import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:ffmpeg_kit_flutter_new_video/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_video/return_code.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  VideoPlayerController? _controller;
  String? _videoPath;
  double _startTime = 0;
  double _endTime = 0;
  double _duration = 0;
  String _textOverlay = '';
  double _speed = 1.0;
  bool _isProcessing = false;
  String _status = '导入视频开始剪辑';

  Future<void> _pickVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
    );
    if (result == null || result.files.single.path == null) return;

    final path = result.files.single.path!;
    final controller = VideoPlayerController.file(File(path));
    await controller.initialize();

    setState(() {
      _controller?.dispose();
      _controller = controller;
      _videoPath = path;
      _duration = controller.value.duration.inMilliseconds / 1000.0;
      _startTime = 0;
      _endTime = _duration;
      _status = '已加载视频，可进行编辑';
    });

    controller.setLooping(true);
    controller.play();
  }

  Future<void> _exportVideo() async {
    if (_videoPath == null) return;

    setState(() {
      _isProcessing = true;
      _status = '正在导出...';
    });

    final dir = await getTemporaryDirectory();
    final outputPath = '${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.mp4';

    // 构建 FFmpeg 命令
    final start = _startTime.toStringAsFixed(2);
    final duration = (_endTime - _startTime).toStringAsFixed(2);

    String cmd = '-y -i "$_videoPath" -ss $start -t $duration';

    List<String> filters = [];
    if (_speed != 1.0) {
      filters.add('setpts=${(1 / _speed).toStringAsFixed(3)}*PTS');
    }
    if (_textOverlay.isNotEmpty) {
      final safeText = _textOverlay.replaceAll("'", "\\'").replaceAll(":", "\\:");
      filters.add(
        "drawtext=text='$safeText':fontsize=48:fontcolor=white:x=(w-text_w)/2:y=h-th-60",
      );
    }

    if (filters.isNotEmpty) {
      cmd += ' -vf "${filters.join(',')}"';
    }

    cmd += ' -c:v libx264 -preset ultrafast -crf 23 -c:a aac "$outputPath"';

    final session = await FFmpegKit.execute(cmd);
    final returnCode = await session.getReturnCode();

    setState(() {
      _isProcessing = false;
      if (ReturnCode.isSuccess(returnCode)) {
        _status = '导出成功！\n文件：$outputPath';
      } else {
        _status = '导出失败，请检查视频格式';
      }
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('剪辑器', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: _isProcessing ? null : _exportVideo,
          ),
        ],
      ),
      body: Column(
        children: [
          // 预览区（主流 APP 风格）
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.black,
              child: Center(
                child: _controller == null
                    ? const Text('点击下方导入视频', style: TextStyle(color: Colors.grey))
                    : AspectRatio(
                        aspectRatio: _controller!.value.aspectRatio,
                        child: VideoPlayer(_controller!),
                      ),
              ),
            ),
          ),

          // 时间线区域（简化版，可扩展为多轨）
          Container(
            height: 120,
            color: const Color(0xFF1A1A1A),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                Text(
                  '时间线  ${_startTime.toStringAsFixed(1)}s - ${_endTime.toStringAsFixed(1)}s',
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                if (_duration > 0)
                  RangeSlider(
                    values: RangeValues(_startTime, _endTime),
                    min: 0,
                    max: _duration,
                    divisions: (_duration * 10).toInt(),
                    activeColor: const Color(0xFF00E676),
                    inactiveColor: Colors.grey[800],
                    onChanged: (values) {
                      setState(() {
                        _startTime = values.start;
                        _endTime = values.end;
                        _controller?.seekTo(
                          Duration(milliseconds: (_startTime * 1000).toInt()),
                        );
                      });
                    },
                  ),
              ],
            ),
          ),

          // 底部工具栏（CapCut 风格）
          Container(
            height: 100,
            color: const Color(0xFF121212),
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
              children: [
                _toolButton(Icons.video_library, '导入', _pickVideo),
                _toolButton(Icons.content_cut, '剪切', () {}),
                _toolButton(Icons.text_fields, '文字', _showTextDialog),
                _toolButton(Icons.speed, '变速', _showSpeedDialog),
                _toolButton(Icons.tune, '滤镜', () {}),
                _toolButton(Icons.music_note, '音乐', () {}),
                _toolButton(Icons.auto_awesome, '特效', () {}),
              ],
            ),
          ),

          // 状态栏
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: const Color(0xFF0A0A0A),
            child: Text(
              _status,
              style: const TextStyle(fontSize: 12, color: Color(0xFF00E676)),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _toolButton(IconData icon, String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 70,
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: const Color(0xFF00E676), size: 26),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }

  void _showTextDialog() {
    final controller = TextEditingController(text: _textOverlay);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text('添加文字'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: '输入要叠加的文字'),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              setState(() => _textOverlay = controller.text);
              Navigator.pop(ctx);
            },
            child: const Text('确定', style: TextStyle(color: Color(0xFF00E676))),
          ),
        ],
      ),
    );
  }

  void _showSpeedDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('播放速度', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            Slider(
              value: _speed,
              min: 0.25,
              max: 4.0,
              divisions: 15,
              label: '${_speed.toStringAsFixed(2)}x',
              activeColor: const Color(0xFF00E676),
              onChanged: (v) => setState(() => _speed = v),
            ),
            Text('${_speed.toStringAsFixed(2)}x'),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
