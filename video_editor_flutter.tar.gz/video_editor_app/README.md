# 主流风格视频剪辑 APP（Flutter）

界面按 CapCut / VN / InShot 风格设计：上方预览、下方时间线、底部工具栏。

## 当前功能

- 导入本地视频
- 精确裁剪
- 添加文字叠加
- 变速
- 导出 MP4

## 如何获得可安装的 APK（推荐：GitHub Actions，免费）

### 步骤（手机也能完成大部分）

1. 在手机浏览器打开 [github.com](https://github.com) 注册/登录账号。
2. 点击右上角 **+** → **New repository**。
   - 仓库名随意（例如 `video-editor`）
   - 选择 **Public**
   - 不要勾选添加 README
   - 创建仓库
3. 把整个 `video_editor_app` 文件夹里的所有文件上传到这个仓库（可以用 GitHub 网页的 “Upload files” 功能）。
4. 上传完成后，进入仓库的 **Actions** 标签页。
5. 如果提示启用 Actions，点击确认。
6. 等待构建完成（大约 5–15 分钟）。
7. 构建成功后，进入该次运行记录，在页面底部 **Artifacts** 区域下载 `video-editor-apk`。
8. 解压得到 `app-release.apk`，传到手机安装即可。

### 触发方式

- 每次推送到 `main` 或 `master` 分支会自动构建。
- 也可以在 Actions 页面手动点击 **Run workflow**。

## 本地构建（有电脑时）

```bash
cd video_editor_app
flutter pub get
flutter build apk --release
```

APK 位置：`build/app/outputs/flutter-apk/app-release.apk`

## 注意事项

- 首次构建会下载 Flutter 和依赖，时间稍长属正常。
- 如果构建失败，把 Actions 日志发给我，我帮你修。
- 当前是可运行的基础版本，后续可继续加多轨时间线、滤镜、自动字幕等。

需要我现在再补充多轨时间线、更完整的 CapCut 风格 UI，或修复可能的构建问题，直接说。
